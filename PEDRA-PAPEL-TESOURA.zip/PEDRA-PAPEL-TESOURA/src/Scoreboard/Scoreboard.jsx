import React from "react";

function Scoreboard({ playerScore, computerScore, draws }) {
  return (
    <div>
      <h2>Placar</h2>
      <p>Jogador: {playerScore}</p>
      <p>Computador: {computerScore}</p>
      <p>Empates: {draws}</p>
    </div>
  );
}

export default Scoreboard;