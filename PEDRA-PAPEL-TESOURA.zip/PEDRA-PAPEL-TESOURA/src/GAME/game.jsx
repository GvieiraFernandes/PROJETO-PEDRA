import React from "react";

function Game({ playGame }) {
  return (
    <div>
      <h2>Escolha sua opção:</h2>
      <button onClick={() => playGame("pedra")}>Pedra</button>
      <button onClick={() => playGame("papel")}>Papel</button>
      <button onClick={() => playGame("tesoura")}>Tesoura</button>
    </div>
  );
}

export default Game;