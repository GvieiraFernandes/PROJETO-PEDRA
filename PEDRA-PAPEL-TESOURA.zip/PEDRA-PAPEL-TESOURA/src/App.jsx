
import React, { useState } from "react";
import Game from "./GAME/game";
import Scoreboard from "./Scoreboard/Scoreboard";


import './App.css'


function App() {

  const [playerChoice, setPlayerChoice] = useState(null); // Escolha do jogador
  const [computerChoice, setComputerChoice] = useState(null); // Escolha do computador
  const [result, setResult] = useState(null); // Resultado da rodada (vitória, empate, derrota)
  const [playerScore, setPlayerScore] = useState(0); // Pontuação do jogador
  const [computerScore, setComputerScore] = useState(0); // Pontuação do computador
  const [draws, setDraws] = useState(0); // Número de empates

  // Define as opções disponíveis para o jogador e o computador.
  const choices = ["pedra", "papel", "tesoura"];

  // Função para jogar o jogo.
  const playGame = (choice) => {
    // Escolhe aleatoriamente a opção do computador.
    const computerRandomChoice =
      choices[Math.floor(Math.random() * choices.length)];

    // Define as escolhas do jogador e do computador.
    setPlayerChoice(choice);
    setComputerChoice(computerRandomChoice);

    // Lógica para determinar o resultado da rodada.
    if (choice === computerRandomChoice) {
      setDraws(draws + 1);
      setResult("Empate!");
    } else if (
      (choice === "pedra" && computerRandomChoice === "tesoura") ||
      (choice === "papel" && computerRandomChoice === "pedra") ||
      (choice === "tesoura" && computerRandomChoice === "papel")
    ) {
      setPlayerScore(playerScore + 1);
      setResult("Você venceu!");
    } else {
      setComputerScore(computerScore + 1);
      setResult("O computador venceu!");
    }
  };

  // Função para reiniciar o jogo.
  const resetGame = () => {
    setPlayerChoice(null);
    setComputerChoice(null);
    setResult(null);
  };

  // URL da imagem a ser usada como fundo.
  const imageUrl = "https://media.istockphoto.com/id/1395632555/pt/vetorial/colorful-hand-icon-set.jpg?s=1024x1024&w=is&k=20&c=-AOUflUzGSp_kUSIDp0jZ6s7kCCSp0zUh5rUrCQREQk="

  // Renderiza o componente App.
  return (
    <div className="App">
      {/* Exibe a imagem de fundo */}
      <img src={imageUrl}></img>

      {/* Exibe o título do jogo */}
      <h1>Jogo Pedra, Papel, Tesoura</h1>

      {/* Renderiza o componente Game e passa a função playGame como prop */}
      <Game playGame={playGame} />

      {/* Renderiza o componente Scoreboard e passa as pontuações e empates como props */}
      <Scoreboard
        playerScore={playerScore}
        computerScore={computerScore}
        draws={draws}
      />

      {/* Exibe o resultado da rodada e um botão para jogar novamente */}
      {result && (
        <div>
          <p>{result}</p>
          <button onClick={resetGame}>Jogar Novamente</button>
        </div>
      )}
    </div>
  );
}

// Exporta o componente App como o componente padrão deste arquivo.
export default App;